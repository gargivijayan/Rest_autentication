from django.urls import path
from .views import PhoneNumberListView


from .views import UserLoginView

urlpatterns = [
    path('signup/',  PhoneNumberListView.as_view()), 
    path('api/login/', UserLoginView.as_view(), name='user-login'),
    
    
   
]


 





  
    

