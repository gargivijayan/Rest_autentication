# serializers.py
from rest_framework import serializers
from django.contrib.auth.models import User
from .models import PhoneNumber

# class PhoneNumberSerializer(serializers.ModelSerializer):
#     phone_number = serializers.CharField(required=False)

#     class Meta:
#         model = PhoneNumber
#         fields = ['phone_number']  

# class UserSerializer(serializers.ModelSerializer):
#     ph = PhoneNumberSerializer(required=False)

#     class Meta:
#         model = User
#         fields = ['username', 'email', 'first_name', 'last_name', 'ph', 'password']
#         extra_kwargs = {
#             'password': {'write_only': True},
#         }

#     def create(self, validated_data):
#         phone_number_data = validated_data.pop('ph', None)
#         user = User.objects.create_user(**validated_data)
#         if phone_number_data:
#             PhoneNumber.objects.create(user=user, **phone_number_data)
#         return user
    
    
    

class PhoneNumberSerializer(serializers.ModelSerializer):
    class Meta:
        model = PhoneNumber
        fields = ['phone_number']

class UserSerializer(serializers.ModelSerializer):
    ph = PhoneNumberSerializer(required=False)

    class Meta:
        model = User
        fields = ['username', 'email', 'first_name', 'last_name', 'ph', 'password']
        extra_kwargs = {
            'password': {'write_only': True},
        }

    def create(self, validated_data):
        phone_number_data = validated_data.pop('ph', None)
        user = User.objects.create_user(**validated_data)
        if phone_number_data:
            PhoneNumber.objects.create(user=user, **phone_number_data)
        return user








# from rest_framework import serializers

# class UserLoginSerializer(serializers.Serializer):
#     username = serializers.CharField()
#     password = serializers.CharField(write_only=True)



from rest_framework import serializers
from django.contrib.auth.models import User

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['username', 'email', 'first_name', 'last_name']

class UserLoginSerializer(serializers.Serializer):
    username = serializers.CharField()
    password = serializers.CharField(write_only=True)


